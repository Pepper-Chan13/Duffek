function setup() {
  createCanvas(1000, 1000);
  frameRate(30);
}
let y;
let value = (255,221,221)
function draw() {
background(255,221,221);
  colorMode(RGB)
  
  let num = 30;
  let x1 = 700;
  let y1 = 700;
  let x2 = mouseX;
  let y2 = mouseY;
  
  fill(255);
  y=60;
  for (let i=0; i < num / 3; i++) {
    rect(200, y, 700, 20);
    y += 25;
  }
  
  line(x1,y1,x2,y2) 
  if (keyIsPressed ===true) {
    fill(136,207,241);
  } else {
    fill(230,246,255);
  }
  ellipse(x2, y2, 200, 200);
  
  fill(value);
  ellipse(700,700,200);
}
    function mouseClicked(){
      if (value === 0){
        value = RGB;
      } else {
        value = 0;
      }
}