function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(70);
  stroke(0.5)
  fill(255)
  arc(300, 50, 80, 90, 0.7, PI+ QUARTER_PI,OPEN);
  fill(210)
  quad(120, 120, 200, 120, 200, 270, 120, 270,)
  fill(255, 13, 10)
  triangle(160, 75, 200, 120, 120, 120);
  triangle(120, 200, 120, 290, 70, 290);
  triangle(200, 200, 250, 290, 200, 290);
  fill(242, 255, 10)
  quad(160, 280, 200, 350, 160, 310, 120, 350)
  fill(255, 77, 0)
  beginShape();
  vertex(160, 325);
  vertex(175, 350)
  vertex(160, 390)
  vertex(145, 350)
  vertex(160,325)
  endShape()
  noFill();
  colorMode(RGB,204, 229, 255,1);
  strokeWeight(4);
  stroke(137, 207, 239, 0.3);
  circle(275, 40, 20);
  circle(282, 50, 20);
  circle(290,60,20)
  circle(297,70,20)
  circle(307,80,20)
  
  
  }