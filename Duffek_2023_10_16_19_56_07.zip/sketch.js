var num = 200;
var x = [];
var y = [];

function setup() {
  createCanvas(1200, 1200);
  for (var i = 0; i < num; i++) {
    x[i]=0;
    y[i]=0;
    noStroke();
  }
}
  

function draw() {
  background(220);
  x[0] += 0.5;
  x[1]+= 0.5;
  print(x.length);
  arc(x[0], 30,40,40,102,50.76);
  arc (x[1], 90,40,40,102, 50.76);
  print(y.length);
  
  
  
  for (var i = num-1; i>0; i--){
    x[i] = x[i-1];
    y[i] = y[i-1];
  }
  x[0]=mouseX;
  y[0]= mouseY;
  for (var i = 0; i<num; i++){
    fill (i*10);
    arc(x[i],y[i],40,40,140,70);
  }
}